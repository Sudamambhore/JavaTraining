package com.example.HttpMethods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpMethodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpMethodsApplication.class, args);
	}

}
