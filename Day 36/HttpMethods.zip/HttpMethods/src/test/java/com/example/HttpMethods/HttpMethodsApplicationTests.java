package com.example.HttpMethods;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpMethodsApplicationTests {

	@Test
	void contextLoads() {
	}

}
